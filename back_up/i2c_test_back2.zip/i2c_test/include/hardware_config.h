#ifndef _HARDWARE_CONFIG_H_
#define _HARDWARE_CONFIG_H_



//            General purpose output
#define gpio_mode_pp_2						0x1
#define gpio_mode_pp_10						0x2
#define gpio_mode_pp_50						0x3

#define gpio_mode_od_2						0x5
#define gpio_mode_od_10						0x6
#define gpio_mode_od_50						0x7

//             Alternate Function output
#define alternate_mode_pp_2					0x9
#define alternate_mode_pp_10				0xA
#define alternate_mode_pp_50				0xB

#define alternate_mode_od_2					0xD
#define alternate_mode_od_10				0xE
#define alternate_mode_od_50				0xF

//                Input
#define input_mode_analog				    0
#define input_mode_floating				    0x4
#define input_mode_pull_down_up			    0x8


//                                       PINS
//USART1
/*
#define usart_tx_port							       	 GPIOA
#define usart_tx_pin							        	9
#define usart_tx_pin_mode					     alternate_mode_pp_50

#define usart_rx_port								     GPIOA
#define usart_rx_pin							        	10
#define usart_rx_pin_mode						 input_mode_floating

//ADC 
#define usart_tx_port							       	 GPIOA
#define usart_tx_pin							        	1
#define usart_tx_pin_mode					     input_mode_analog
*/







#endif //_HARDWARE_CONFIG_H_
