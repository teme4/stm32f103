#include <stm32f1xx.h>
#include "gpio.h"
#include "tim_Delay.h"
#include "ADC.h"
#include "math.h"

#define B 3950 // B-коэффициент
#define SERIAL_R 10000 // сопротивление последовательного резистора, 10 кОм
#define THERMISTOR_R 100000 // номинальное сопротивления термистора, 100 кОм
#define NOMINAL_T 25 // номинальная температура (при которой TR = 100 кОм)

int main()
{

SetSysClockTo72();
setupPin(GPIOC,13,gpio_mode_pp_50);
ADC_init();
TIM2_Init('m',1000);
double tr,steinhart,temp;
//double U_val=0,g=0;
TIM_EnableIT_UPDATE(TIM2);
TIM_EnableCounter(TIM2);  


while(1)
{
//int t =ADC_mess();
  //  tr = 4095 / t;
    tr = SERIAL_R / ADC_mess();


 steinhart = tr / THERMISTOR_R; // (R/Ro)
    steinhart = log(steinhart); // ln(R/Ro)
    steinhart /= B; // 1/B * ln(R/Ro)
    steinhart += 1.0 / (NOMINAL_T + 273.15); // + (1/To)
    steinhart = 1.0 / steinhart; // Invert
    steinhart -= 273.15; 

tr = 4095 / 2;
}
return 0;
}
