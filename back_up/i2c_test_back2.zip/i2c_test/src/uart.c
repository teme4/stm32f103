#include "gpio.h"
#include <string.h>

uint8_t len=0;
unsigned char data;

/*Trancmited 1 byte*/
void uart_tx_byte( unsigned char data)
{
while ((USART1->SR & USART_SR_TXE) == 0)  {}
USART1->DR = data;
} 
/*Trancmited array bytes*/
/*
void uart_tx_bytes(unsigned char * data)
{
len = strlen(data); 
while(len--)
{
uart_tx_byte(*data++);
}
}  */

/*
void uart_tx_data(unsigned char * data)
{
len = strlen(data); 
while(len--)
{
uart_tx_byte(*data++);
}
}*/


/*Enter*/
void uart_enter()
{
while ((USART1->SR & USART_SR_TXE) == 0)  {}
USART1->DR = 0x0D;
while ((USART1->SR & USART_SR_TXE) == 0)  {}
USART1->DR = 0x0A;
} 
/*Init*/
void usart_init()
{
RCC->APB2ENR |= RCC_APB2ENR_USART1EN; 
USART1->BRR = 69;//11520
USART1->CR1 = USART_CR1_UE | USART_CR1_RXNEIE | USART_CR1_RE |USART_CR1_TE; 
NVIC_EnableIRQ(USART1_IRQn);
__enable_irq();
}




/*
void USART1_IRQHandler()
{
uint8_t data=USART1->DR;
USART1->DR=data;
}*/
