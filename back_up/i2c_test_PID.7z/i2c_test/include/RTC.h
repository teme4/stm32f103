/*const*/
/*
int mask=0x0F;
	int mask1=0xF0;
	unsigned char sec=0,min=0,hour=0;
	unsigned char sece=0,mine=0,houre=0;
uint8_t aTxBuffer[18];

	void set_time(int hour,int min,int sec)
	{
		int x,y,a,b,m,n;
		a=hour/10;
		b=hour%10;
		x=min/10;
		y=min%10;
		m=sec/10;
		n=sec%10;
		x=x<<4;
		a=a<<4;
		m=m<<4;
		hour=a+b;
		min=x+y;
		sec=m+n;
		/////////////////
		aTxBuffer[0]=0x00;
		CMSIS_I2C_Adress_Device_Scan(aTxBuffer[0]) ;
		aTxBuffer[1]=sec;
		CMSIS_I2C_Adress_Device_Scan(aTxBuffer[1]) ;
	    ///////////////
		aTxBuffer[0]=0x02;
		CMSIS_I2C_Adress_Device_Scan(aTxBuffer[0]) ;
		aTxBuffer[1]=hour;
		CMSIS_I2C_Adress_Device_Scan(aTxBuffer[1]) ;		
		  ///////////////
		aTxBuffer[0]=0x01;
		CMSIS_I2C_Adress_Device_Scan(aTxBuffer[0]) ;
		aTxBuffer[1]=min;
		CMSIS_I2C_Adress_Device_Scan(aTxBuffer[1]) ;		
	}*/
	/*void set_day_weak(int day)
	{
		aTxBuffer[0]=0x03;
		aTxBuffer[1]=day;
		HAL_I2C_Master_Transmit(&hi2c1, 0xD0,aTxBuffer,  2, 500);
	}
	void set_date(int date)
	{
		int a,b;
		a=date/10;
		b=date%10;
		a=a<<4;
		date=a+b;
		aTxBuffer[0]=0x04;
		aTxBuffer[1]=date;
		HAL_I2C_Master_Transmit(&hi2c1, 0xD0,aTxBuffer,  2, 500);
	}

	void set_month(int month)
	{
		int a,b;
		a=month/10;
		b=month%10;
		a=a<<4;
		month=a+b;
		aTxBuffer[0]=0x05;
		aTxBuffer[1]=month;
		HAL_I2C_Master_Transmit(&hi2c1, 0xD0,aTxBuffer,  2, 500);
	}

	void set_year(int year)
	{
		int a,b;
		a=year/10;
		b=year%10;
		a=a<<4;
		year=a+b;
		aTxBuffer[0]=0x06;
		aTxBuffer[1]=year;
		HAL_I2C_Master_Transmit(&hi2c1, 0xD0,aTxBuffer,  2, 500);
	}*/
/*
	void Receive(void)
	{
		aTxBuffer[0]=0;
        HAL_I2C_Master_Transmit(&hi2c1, 0xD0,aTxBuffer,  1, 300);
        HAL_Delay(100);
	  	HAL_I2C_Master_Receive(&hi2c1,  0xD0, (uint8_t*) &aTxBuffer,  20,500);
	}

	void get_time()
	{
		Receive();
		sece=mask&aTxBuffer[0];
	  	sec=((mask1&aTxBuffer[0])/16)* 10 + sece;
	  	mine=mask&aTxBuffer[1];
	  	min=((mask1&aTxBuffer[1])/16)* 10 + mine;
	  	houre=mask&aTxBuffer[2];
	  	hour=((mask1&aTxBuffer[2])/16)* 10 + houre;
	  	return ((int)hour,(int)min,(int)sec);
	}

void set(int year,int month,int date,int hour,int min,int day)
{
	set_year(year);
	set_month(month);
	set_date(date);
	//set_time(hour,min);
	set_day_weak(day);
}*/

	
