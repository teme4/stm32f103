#include "stm32f1xx.h"

#include "gpio.hpp"
#include "uart.hpp"

int main(void)
{
gpio_init();
usart_init();


while (1)
   {

   }


  return 0;
}

