#include "stm32f1xx.h"
//#include "gpio.h"
#include "hardware_config.h"


void setupPin(GPIO_TypeDef * port, uint32_t pin, uint32_t mode){
 RCC->APB2ENR |= (1 << (((uint32_t)port - APB2PERIPH_BASE) / 0x400));
 if (pin > 7){
  port->CRH &= ~(0xf  << ((pin - 8) * 4));
  port->CRH |= mode << ((pin - 8) * 4);
 }
 else{
  port->CRL &= ~(0xf << (pin * 4));
  port->CRL |= mode << (pin * 4);
 }
}

void Set_pin_H(GPIO_TypeDef *port,uint8_t pin)
{
  port->BSRR = (1<<pin);
}

void Set_pin_L(GPIO_TypeDef *port,uint8_t pin)
{
  port->BRR = (1<<pin);
}

int get_state_Pin (GPIO_TypeDef *port, uint8_t pin)
    {

	uint16_t mask;
	mask = ( 1<< pin);
	if ((port->IDR) & mask) return 1;
	else return 0;
}

void gpio_init()
{ 
 //usart pins
 setupPin(usart_tx_port, usart_tx_pin, usart_tx_pin_mode);
 setupPin(usart_rx_port, usart_rx_pin, usart_rx_pin_mode);

}