#include <stm32f1xx.h>
#include "gpio.h"
#include "tim_Delay.h"
#include "ADC.h"
#include "math.h"
#include "uart.h"
#include "stdio.h"

float X;
char buff[15];
uint8_t n=0;
uint8_t t_val;

float tr;
float temp;
float temp_data(void)
{
   float Rt=0;
   float Rp=100000;
   float T2=273.15+25;
   float Bx=3950;
   float Ka=273.15;
   float vol=0;
   vol=(float)(ADC_mess()*(3.3/4096));
/*X=vol;
for(int i=0;i<14;i++)
{
buff[i]=0;
}
sprintf(buff, "%d.%dv", (int)X, (int)(X * 1000000) % 1000000);
uart_tx_data(buff);
uart_enter();*/


   Rt=(3.3-vol)*10000/vol;
   temp=1/(1/T2+log(Rt/Rp)/Bx)-Ka+0.5;
   return temp;
}
void PWM_init()
{
    // Тактирование  GPIOA , TIM1, альтернативных функций порта
	RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_TIM1EN | RCC_APB2ENR_AFIOEN;
        
        //PA11 push-pull
	GPIOA->CRH &= ~GPIO_CRH_CNF11;
	GPIOA->CRH |= GPIO_CRH_CNF11_1;

	GPIOA->CRH	&= ~GPIO_CRH_MODE11;
	GPIOA->CRH	|= GPIO_CRH_MODE11_1;
}
void PWM_gen(uint8_t fill)
{
//  TIM1->CR1 &= ~TIM_CR1_CEN;
	//делитель
	TIM1->PSC = 72;
	//значение перезагрузки
  TIM1->ARR = 20000;
	//коэф. заполнения
	TIM1->CCR4 = 1000*fill;
	//настроим на выход канал 4, активный уровень низкий 
	TIM1->CCER |= TIM_CCER_CC4E | TIM_CCER_CC4P;
	//разрешим использовать выводы таймера как выходы
	TIM1->BDTR |= TIM_BDTR_MOE;
	//TIM1->BDTR |= TIM_BDTR_BKP;
	
	//PWM mode 1, прямой ШИМ 4 канал
         TIM1->CCMR2 = TIM_CCMR2_OC4M_2 | TIM_CCMR2_OC4M_1; 
        //если надо настроить первый канал, это можно сделать так
        //TIM1->CCMR1 = TIM_CCMR1_OC1M_2 | TIM_CCMR1_OC1M_1;
	//считаем вверх
	TIM1->CR1 &= ~TIM_CR1_DIR;
	//выравнивание по фронту, Fast PWM
	TIM1->CR1 &= ~TIM_CR1_CMS;
	//включаем счётчик
	TIM1->CR1 |= TIM_CR1_CEN;
}

PID(uint8_t t_set)
{
tr=temp_data(); 
t_val=t_set-tr;
if(t_val>1)
{
PWM_gen(t_val);// %  
tr=0;
}
else
{
//TIM1->CR1 &= ~ TIM_CR1_CEN;  
//GPIOA->ODR &= ~(1 << 11);
//Set_pin_L(GPIOA,11);
PWM_gen(0);
}
}

void pid_status(uint8_t stat)
{
if(stat==1)
{
if(n<15)
{
n++;	
X = X+temp_data();
}
else
{
X=X/15;	
buff[0]=0;
buff[1]=0;
buff[2]=0;
buff[3]=0;
sprintf(buff, "%d.%d;%d", (int)X, (int)(X * 100) % 100,t_val);
uart_tx_data(buff);
uart_enter();
/*
sprintf(buff, "%dA", t_val);
uart_tx_data(buff);
uart_enter();*/
n=0;
}
}
stat=0;
}

int main()
{/*
ADC_init();
PWM_init();  */
  
SetSysClockTo72();
ADC_init();
PWM_init();
TIM2_Init('m',500);
gpio_init();
usart_init();
TIM_EnableIT_UPDATE(TIM2);
TIM_EnableCounter(TIM2);  
char str[80];
while(1)
{
PID(60);
if(temp_data()>100)
{
Set_pin_H(GPIOC,13);
}
else
{
Set_pin_L(GPIOC,13);
}    
//sprintf(str,"%f",temp_data);
//printf(str,"%f",(char)temp_data);

//tr=temp_data(); 
//tr=0;
/*
if(tr>=27)
{
PWM_gen(25);// %  
}
else{
PWM_gen(100);// %    
}
*/
}
return 0;
}