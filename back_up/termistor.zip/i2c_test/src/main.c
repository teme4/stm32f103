#include <stm32f1xx.h>
#include "gpio.h"
#include "tim_Delay.h"
#include "ADC.h"
#include "math.h"
#include "uart.h"

float tr;
float temp;
float temp_data(void)
{
   float Rt=0;
   float Rp=100000;
   float T2=273.15+25;
   float Bx=3950;
   float Ka=273.15;
   float vol=0;
   vol=(float)(ADC_mess()*(3.3/4096));
   Rt=(3.3-vol)*10000/vol;
   temp=1/(1/T2+log(Rt/Rp)/Bx)-Ka+0.5;
   return temp;
}



int main()
{
SetSysClockTo72();
setupPin(GPIOC,13,gpio_mode_pp_50);
ADC_init();
TIM2_Init('m',1000);
usart_init();

TIM_EnableIT_UPDATE(TIM2);
TIM_EnableCounter(TIM2);  


while(1)
{

tr=temp_data(); 
uart_tx_byte(tr);
tr=0;

}
return 0;
}
