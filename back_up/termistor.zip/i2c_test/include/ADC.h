#include <stm32f1xx.h>

void ADC_init(void);
double ADC_mess();
